module.exports = {
  clock: '<a:clock:1146275118193049600>',
  gift: '<a:gift:1146275108483248169>',
  tada: '<a:tada:1146275135804944474>',
  tick: '<a:tick:1146275118679601193>',
  cross: '<a:cross:1146275187151601695>',
  warning: '<:warning:1146275137176469554>',
  exclm: '<a:exclm:1146275152200478833>'
}
