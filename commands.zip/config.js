module.exports = {
  prefix: '>',
  clientId: '1189824474921586738',
  guildId: ['1102052303491567697'],
  ownerID: ['935640234698346586']
}
